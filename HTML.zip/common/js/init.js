$(function(){

  console.log('success');

});
